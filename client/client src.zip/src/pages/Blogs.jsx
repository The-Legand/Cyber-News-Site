export default function Blogs(){
    return <h2>Blogs</h2>;
}