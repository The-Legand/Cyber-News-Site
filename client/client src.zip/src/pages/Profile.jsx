export default function Profile(){
    return <h2>Profile</h2>;
}